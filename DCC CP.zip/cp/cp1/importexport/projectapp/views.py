from django.shortcuts import render
from django.http import HttpResponse
from .resources import PersonResource
from tablib import Dataset
from .models import Person
from django.contrib import messages


def export(request):
    person_resource = PersonResource()
    dataset = person_resource.export()
    response = HttpResponse(dataset.xls, content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename="persons.xls"'
    return response


def simple_upload(request):
    if request.method == 'POST':
        person_resource = PersonResource()
        dataset = Dataset()
        new_persons = request.FILES['myfile']
        if not new_persons.name.endswith('xlsx'):
            messages.info(request, 'wrong file format')
            return render(request, 'input.html')
        imported_data = dataset.load(new_persons.read(), format='xlsx')
        # print(imported_data)
        for data in imported_data:
            print(data[1])
            value = Person(
                data[0],
                data[1],
                data[2],
                data[3],
                data[4],
                data[5],
            )
            value.save()
            # result = person_resource.import_data(dataset, dry_run=True)  # Test the data import

        # if not result.has_errors():
        #    person_resource.import_data(dataset, dry_run=False)  # Actually import now

    return render(request, 'input.html')


def home(request):
        data = Person.objects.get(State = 'Total')
        data1 = Person.objects.all()
        para= {'data': data, 'data1': data1}
        return render(request, 'home.html', para)


def vaccine(request):
    return render(request, 'vaccine.html')

def search(request):
    query = request.GET.get('query')
    states = Person.objects.all()
    para = {'states': states,'query':query}
    return render(request, 'search.html', para)



